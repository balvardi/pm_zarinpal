<?php
/**
 * @version	5.0.0 15.02.2023
 * @author	 R.Balvardi
 * @package	Jshopping
 * @copyright	Copyright (C) 2023 DimaGroup.IR. All rights reserved.
 * @license	GNU/GPL
 */
defined('_JEXEC') or die();

class pm_zarinpal extends PaymentRoot {
	private $curlopt_sslversion = 6;

	//function call in admin
		function showAdminFormParams($params){
			$array_params = array('acc', 'transaction_end_status', 'transaction_pending_status', 'transaction_failed_status', 'checkdatareturn');
			foreach ($array_params as $key){
				if (!isset($params[$key])) $params[$key] = '';
			}
			if (!isset($params['address_override'])) $params['address_override'] = 0;
			$orders = \JSFactory::getModel('orders'); //admin model
			include(dirname(__FILE__)."/adminparamsform.php");
		}

		function checkTransaction($pmconfigs, $order, $act) {
			require_once("zarinpal_function.php");

			$MerchantID 		= $pmconfigs['acc'];;
			$order->order_total = $this->fixOrderTotal($order);
			$Amount 			= round($order->order_total);
			$ZarinGate 			= false;
			$SandBox 			= false;

			$zp 	= new zarinpal();
			$result = $zp->verify($MerchantID, $Amount, $SandBox, $ZarinGate);
			$uri = \JURI::getInstance();
			$liveurlhost = $uri->toString(array("scheme", 'host', 'port'));
			if (isset($result["Status"]) && $result["Status"] == 100)
			{
				// Success
				echo "تراکنش با موفقیت انجام شد";
				echo "<br />مبلغ : ". $result["Amount"];
				echo "<br />کد پیگیری : ". $result["RefID"];
				echo "<br />Authority : ". $result["Authority"];
				$db = JFactory::getDBO();
				$db->setQuery("UPDATE `#__jshopping_orders` SET `order_add_info` = '".$result["RefID"]."' WHERE `order_id` ='".$order->order_id."'");
				$db->execute();
				$app = JFactory::getApplication();
				$return = $liveurlhost . \JSHelper::SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=return&itemnumber=".$order->order_id."&js_paymentclass=pm_zarinpal");
				$app->enqueueMessage("تراکنش با موفقیت انجام شد. کد پیگیری : ". $result["RefID"], 'success');
				return array(1, '');
				$app->redirect($return);
			} else {
				// error
				echo "پرداخت ناموفق";
				echo "<br />کد خطا : ". $result["Status"];
				echo "<br />تفسیر و علت خطا : ". $result["Message"];
				$cancel_return = $liveurlhost . \JSHelper::SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=cancel&itemnumber=".$order->order_id."&js_paymentclass=pm_zarinpal");
				$app = JFactory::getApplication();
				$app->enqueueMessage("پرداخت ناموفق", 'danger');
				$app->redirect($cancel_return);
			}
		die();
		}

		function showEndForm($pmconfigs, $order) {
			include(dirname(__FILE__)."/zarinpal_function.php");
			$jshopConfig 	= \JSFactory::getConfig();
			$pm_method 		= $this->getPmMethod();
			$app 			= JFactory::getApplication();
			$sitename 		= htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');
			$item_name 		= sprintf(\JText::_('JSHOP_PAYMENT_NUMBER'), $order->order_number);
			$MerchantID 	= $pmconfigs['acc'];
			$Amount 		= round($order->order_total);
			$Description 	= "پرداخت هزینه فاکتور ".$item_name." در سایت ".$sitename;
			$Email 			= JFactory::getUser()->email;
			$Mobile 		= $order->mobil_phone;
			$Authority 		= $_GET['Authority'];
			$Status 		= $_GET['Status'];
			$uri = \JURI::getInstance();
			$liveurlhost = $uri->toString(array("scheme", 'host', 'port'));
			$CallbackURL = $liveurlhost . \JSHelper::SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=return&itemnumber=".$order->order_id."&js_paymentclass=pm_zarinpal");
				$ZarinGate 		= false;
				$SandBox 		= false;
				$zp 	= new zarinpal();
				$result = $zp->request($MerchantID, $Amount, $Description, $Email, $Mobile, $CallbackURL, $SandBox, $ZarinGate);
				if (isset($result["Status"]) && $result["Status"] == 100):
					$zp->redirect($result["StartPay"]);
				else:
					echo "خطا در ایجاد تراکنش";
					echo "<br />کد خطا : ". $result["Status"];
					echo "<br />تفسیر و علت خطا : ". $result["Message"];
				endif;
		}
		function getUrlParams($pmconfigs) {
			$params = array();
			$params['order_id'] = \JFactory::getApplication()->input->getInt("itemnumber");
			$params['Status'] = \JFactory::getApplication()->input->getInt("Status");
			$params['checkHash'] = 0;
			$params['checkReturnParams'] = $pmconfigs['checkdatareturn'];
			return $params;
            \JSHelper::saveToLog("payment.log", "Params: " . $params);
		}
		function fixOrderTotal($order) {
			$total = $order->order_total;
			$total = round($total);
			return $total;
		}

}
